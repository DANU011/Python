#사용자 정의 모듈

def add(a, b):
    return a + b

def sub(a, b):
    return a - b

def mul(a, b):
    return a * b

def div(a, b):
    return a / b



if __name__ == '__main__':
    print(add(3, 5))
    print(sub(10, 7))
    print(mul(10, 2))
    print(div(10, 5))
