> web crawling 연습

## 설정
* Python <= `3.10.10`
* `bs4`, `requests` 설치