# 사용자 정의 모듈 test

import mymath
a=mymath.add(5,20)
print(a)