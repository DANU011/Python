> pandas와 matplotlib를 연습해보기 위한 저장소

## 설정
* Python <= `3.10.10`
* `pandas`, `matplotlib` 설치

```shell
$ python -m venv venv
$ .\venv\Scripts\activate
$ (venv) pip install -r requirements.txt
```