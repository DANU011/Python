#키워드 매개변수 kwargs ,**kwargs

#SyntaxError: invalid non-printable character U+00A0
#복사한 코드의 스페이스(space)가 파이썬의 포맷과 같지 않아서 발생한 에러